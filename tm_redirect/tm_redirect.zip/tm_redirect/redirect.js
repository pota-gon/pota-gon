const oldDomain = "tm.lucky-duet.com";
const newDomain = "tm.yumineko.com";
const redirectPattern = /^ww\d+\.lucky-duet\.com$/; // `ww1`, `ww12` 等をキャッチ

try {
  const url = new URL(window.location.href);

  // 元のドメインまたはリダイレクト先ドメイン
  if (url.hostname === oldDomain || redirectPattern.test(url.hostname)) {
    const newUrl = `https://${newDomain}${url.pathname}${url.search}${url.hash}`;
    window.location.replace(newUrl);
  }
} catch (e) {
}