chrome.webNavigation.onBeforeNavigate.addListener(
  function(details) {
    const oldDomain = "tm.lucky-duet.com";
    const newDomain = "tm.yumineko.com";
    const redirectPattern = /^ww\d+\.lucky-duet\.com$/;

    try {
      const url = new URL(details.url);
      if (url.hostname === oldDomain || redirectPattern.test(url.hostname)) {
        const newUrl = `https://${newDomain}${url.pathname}${url.search}${url.hash}`;
        // 即時リダイレクト
        chrome.tabs.update(details.tabId, { url: newUrl });
      }
    } catch (e) {
    }
  },
  { url: [{ hostContains: "lucky-duet.com" }] }
);